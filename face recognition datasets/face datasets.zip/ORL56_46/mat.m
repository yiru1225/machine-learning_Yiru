clc; clear;
filename='ORL5646';
Datalist=dir(['E:\将批量的图片保存为mat\',filename,'\*']);
Datalist=Datalist(3:end);
for i = 1 : length(Datalist)
    NRD(:,:,i) = imread(sprintf(['E:\\将批量的图片保存为mat\\',filename,'\\',filename,'_%d.bmp'], i));
end
% for i = 1 : length(Datalist)
%     NRD(:,:,i) = (NRD(:,:,i)~=0);
% end
% NRD=uint8(NRD);
save(['D:\',filename,'.mat'],'NRD') %保存到指定路径

