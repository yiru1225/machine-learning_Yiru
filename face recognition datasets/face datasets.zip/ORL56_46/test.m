 a=imread(strcat('C:\AR_Gray_50by40\AR001-1.tif')); 
 b = reshape(a,2000 , 1) 